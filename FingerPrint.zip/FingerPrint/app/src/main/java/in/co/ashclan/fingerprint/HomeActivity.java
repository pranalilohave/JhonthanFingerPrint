package in.co.ashclan.fingerprint;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.ashokvarma.bottomnavigation.BottomNavigationBar;
import com.ashokvarma.bottomnavigation.BottomNavigationItem;

import net.gotev.uploadservice.MultipartUploadRequest;
import net.gotev.uploadservice.ServerResponse;
import net.gotev.uploadservice.UploadInfo;
import net.gotev.uploadservice.UploadServiceBroadcastReceiver;
import net.gotev.uploadservice.UploadStatusDelegate;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.ArrayList;
import java.util.UUID;

import in.co.ashclan.ashclancalendar.data.Day;
import in.co.ashclan.ashclancalendar.widget.CollapsibleCalendar;
import in.co.ashclan.database.DataBaseHelper;
import in.co.ashclan.model.EventPOJO;
import in.co.ashclan.model.MemberPOJO;
import in.co.ashclan.utils.PreferenceUtils;

public class HomeActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,
        BottomNavigationBar.OnTabSelectedListener,
        View.OnClickListener
{

    DataBaseHelper dataBaseHelper;
    BottomNavigationBar bottomNavigationBar;
    FloatingActionButton fab;
    CollapsibleCalendar collapsibleCalendar;

    ArrayList<MemberPOJO> list = new ArrayList<MemberPOJO>();
    ArrayList<EventPOJO> eventList = new ArrayList<EventPOJO>();
    int lastSelectedPosition = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dataBaseHelper = new DataBaseHelper(HomeActivity.this);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        bottomNavigationBar = (BottomNavigationBar)findViewById(R.id.bottom_navigation_bar);
        collapsibleCalendar = findViewById(R.id.collapsibleCalendarView);

        list.addAll(dataBaseHelper.getAllMembers());
        eventList.addAll(dataBaseHelper.getAllEvent());

        Toast.makeText(HomeActivity.this,list.toString(),Toast.LENGTH_LONG).show();
        fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(HomeActivity.this,MemberRegisterActivity.class);
                startActivity(intent);
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        bottomNavigationBar.setTabSelectedListener(this);
        refresh();
        Day day = collapsibleCalendar.getSelectedDay();
        Toast.makeText(HomeActivity.this,"Selected Day: "
                + day.getYear() + "/" + (day.getMonth() + 1) + "/" + day.getDay(),Toast.LENGTH_LONG).show();
        Log.e("outside1:--> ","Selected Day: "
                + day.getYear() + "/" + (day.getMonth() + 1) + "/" + day.getDay());

        calendar();


    }

    public void calendar(){
        System.out.println("Testing date "+collapsibleCalendar.getSelectedDay().getDay()+"/"+collapsibleCalendar.getSelectedDay().getMonth()+"/"+collapsibleCalendar.getSelectedDay().getYear());
        collapsibleCalendar.setCalendarListener(new CollapsibleCalendar.CalendarListener() {
            @Override
            public void onDaySelect() {
                Day day = collapsibleCalendar.getSelectedDay();
                Toast.makeText(HomeActivity.this,"onDaySelect Selected Day: "
                        + day.getYear() + "/" + (day.getMonth() + 1) + "/" + day.getDay(),Toast.LENGTH_LONG).show();
                Log.e("onDaySelect:--> ","Selected Day: "
                        + day.getYear() + "/" + (day.getMonth() + 1) + "/" + day.getDay());

            }

            @Override
            public void onItemClick(View v) {
                Day day = collapsibleCalendar.getSelectedDay();
                Toast.makeText(HomeActivity.this,"onItemClick Selected Day: "
                      + day.getYear() + "/" + (day.getMonth() + 1) + "/" + day.getDay(),Toast.LENGTH_LONG).show();
                Log.e("onItemClick:--> ","Selected Day: "
                        + day.getYear() + "/" + (day.getMonth() + 1) + "/" + day.getDay());

            }

            @Override
            public void onDataUpdate() {
                Day day = collapsibleCalendar.getSelectedDay();
                Toast.makeText(HomeActivity.this,"onDataUpdate Selected Day: "
                        + day.getYear() + "/" + (day.getMonth() + 1) + "/" + day.getDay(),Toast.LENGTH_LONG).show();
                Log.e("onDataUpdate:--> ","Selected Day: "
                        + day.getYear() + "/" + (day.getMonth() + 1) + "/" + day.getDay());

            }

            @Override
            public void onMonthChange() {
                Day day = collapsibleCalendar.getSelectedDay();
                Log.e("onMonthChange:--> ","Selected Day: "
                        + day.getYear() + "/" + (day.getMonth() + 1) + "/" + day.getDay());

                Toast.makeText(HomeActivity.this,"onMonthChange Selected Day: "
                        + day.getYear() + "/" + (day.getMonth() + 1) + "/" + day.getDay(),Toast.LENGTH_LONG).show();

            }

            @Override
            public void onWeekChange(int position) {
                Day day = collapsibleCalendar.getSelectedDay();
                Toast.makeText(HomeActivity.this,"postion: "+position,Toast.LENGTH_LONG).show();
                Log.e("onWeekChange:--> ","Selected Day: "
                        + day.getYear() + "/" + (day.getMonth() + 1) + "/" + day.getDay());

            }
        });

    }
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            PreferenceUtils.setSignIn(HomeActivity.this,false);
            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_member) {
            bottomNavigationBar.setVisibility(View.GONE);
            fab.setVisibility(View.GONE);
            MemberFragment memberFragment = MemberFragment.newInstance(list);
            FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction()
                    .setCustomAnimations(R.anim.anim_slide_in_from_left,
                            R.anim.anim_slide_out_from_left)
                    .replace(R.id.relativeLayout,
                            memberFragment,
                            memberFragment.getTag()).commit();
            Toast.makeText(HomeActivity.this, "Advertisement", Toast.LENGTH_SHORT).show();

        } else if (id == R.id.nav_events) {
            Intent intent = new Intent(HomeActivity.this,EventsActivity.class);
            startActivity(intent);

        } else if (id == R.id.nav_recording) {
            Intent intent = new Intent(HomeActivity.this,RecordingActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_setting) {
            Intent intent = new Intent(HomeActivity.this,MemberDetailsActivity.class);
            startActivity(intent);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    //BottNavigationBar
    @Override
    public void onTabSelected(int position) {
        lastSelectedPosition = position;
        //setMe

        setFragment(position);

    }

    @Override
    public void onTabUnselected(int position) {

    }

    @Override
    public void onTabReselected(int position) {


    }

    //View.OnclickListener
    @Override
    public void onClick(View view) {

    }

    private void refresh(){
        bottomNavigationBar.clearAll();
        bottomNavigationBar.setFab(fab);
        setFragment(0);

        bottomNavigationBar.setMode(BottomNavigationBar.MODE_SHIFTING);
        bottomNavigationBar.setBackgroundStyle(BottomNavigationBar.BACKGROUND_STYLE_DEFAULT);


        bottomNavigationBar
                .addItem(new BottomNavigationItem(R.drawable.ic_overview, "OverView").setActiveColorResource(R.color.blue4))
                .addItem(new BottomNavigationItem(R.drawable.ic_attender, "Attender").setActiveColorResource(R.color.blue3))
                .addItem(new BottomNavigationItem(R.drawable.ic_report_1, "Reports").setActiveColorResource(R.color.blue2))
                .addItem(new BottomNavigationItem(R.drawable.ic_volunteers, "Volunteers").setActiveColorResource(R.color.blue3))
                .addItem(new BottomNavigationItem(R.drawable.ic_edit, "Edit").setActiveColorResource(R.color.blue4))
                .setFirstSelectedPosition(lastSelectedPosition)
                .initialise();
    }

    private void setFragment(int position){

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        finish();
        startActivity(getIntent());
    }

}
