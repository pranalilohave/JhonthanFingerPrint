package in.co.ashclan.fingerprint;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ashokvarma.bottomnavigation.BottomNavigationBar;
import com.ashokvarma.bottomnavigation.BottomNavigationItem;

import java.util.ArrayList;

import in.co.ashclan.database.DataBaseHelper;
import in.co.ashclan.model.MemberPOJO;
import in.co.ashclan.utils.PreferenceUtils;

public class MemberDetailsActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,
        BottomNavigationBar.OnTabSelectedListener,
        View.OnClickListener {

    BottomNavigationBar bottomNavigationBar;
    LinearLayout linearLayout;
    TextView textViewName, textViewId, textViewAge, textViewGender, textViewStatus, textViewMaritalStatus,
            textViewEmail, textViewMobilePhone, textViewHomePhone, textViewWorkPhone, textViewAddress;
    ImageView profileImageView, editImageView;
    ViewPager viewPagerMember;
    int lastSelectedPosition = 0;
    MemberPOJO memberDetails = new MemberPOJO();
    ArrayList<MemberPOJO> list=new ArrayList<MemberPOJO>();
    DataBaseHelper dataBaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member_details_hm);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        dataBaseHelper = new DataBaseHelper(this);

        bottomNavigationBar = (BottomNavigationBar)findViewById(R.id.bottom_navigation_bar);
        list.addAll(dataBaseHelper.getAllMembers());


        inits();
        memberDetails=(MemberPOJO) getIntent().getSerializableExtra("member_details");
        navigationBar();
        textViewId.setText(memberDetails.getRollNo());
        textViewName.setText(memberDetails.getFirstName()+" "+memberDetails.getLastName());
        textViewGender.setText(memberDetails.getGender());
        textViewStatus.setText(memberDetails.getStatus());
        textViewMaritalStatus.setText(memberDetails.getMaritalStatus());
        textViewMobilePhone.setText(memberDetails.getMobilePhone());
        textViewAddress.setText(memberDetails.getAddress());

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        bottomNavigationBar.setTabSelectedListener(this);

    }

    public void inits(){
        linearLayout = (LinearLayout)findViewById(R.id.layout_details);
        bottomNavigationBar = (BottomNavigationBar)findViewById(R.id.bottom_navigation_bar);
        viewPagerMember = (ViewPager)findViewById(R.id.member_view_pager);

        profileImageView = (ImageView)findViewById(R.id.profile_image);
        editImageView = (ImageView)findViewById(R.id.edit);

        textViewName = (TextView)findViewById(R.id.member_name);
        textViewId = (TextView)findViewById(R.id.member_id);
        textViewAge = (TextView)findViewById(R.id.member_age);
        textViewGender = (TextView)findViewById(R.id.member_gender);
        textViewStatus = (TextView)findViewById(R.id.member_status);
        textViewMaritalStatus = (TextView)findViewById(R.id.member_marital_status);
        textViewEmail = (TextView)findViewById(R.id.member_email);
        textViewMobilePhone = (TextView)findViewById(R.id.member_mobile_phone);
        textViewHomePhone = (TextView)findViewById(R.id.member_home_phone);
        textViewWorkPhone = (TextView)findViewById(R.id.member_work_phone);
        textViewAddress = (TextView)findViewById(R.id.member_address);

        bottomNavigationBar.setTabSelectedListener(this);
        editImageView.setOnClickListener(this);
    }


    //BottomNavigationBar.OnTabSelectedListener
    @Override
    public void onTabSelected(int position) {
        lastSelectedPosition = position;
        setFragment(position);
    }

    @Override
    public void onTabUnselected(int position) {

    }

    @Override
    public void onTabReselected(int position) {

    }

    //View.OnClickListerner
    @Override
    public void onClick(View view) {

    }

    private void navigationBar(){
        bottomNavigationBar.clearAll();
        setFragment(0);

        bottomNavigationBar.setMode(BottomNavigationBar.MODE_SHIFTING);
        bottomNavigationBar.setBackgroundStyle(BottomNavigationBar.BACKGROUND_STYLE_DEFAULT);


        bottomNavigationBar
                .addItem(new BottomNavigationItem(R.drawable.ic_volunteers, "Groups").setActiveColorResource(R.color.blue4))
                .addItem(new BottomNavigationItem(R.drawable.ic_attender, "Attendance").setActiveColorResource(R.color.blue3))
                .addItem(new BottomNavigationItem(R.drawable.ic_contributions, "Contributions").setActiveColorResource(R.color.blue2))
                .addItem(new BottomNavigationItem(R.drawable.ic_pledges, "Pledges").setActiveColorResource(R.color.blue3))
                .addItem(new BottomNavigationItem(R.drawable.ic_volunteers, "Family").setActiveColorResource(R.color.blue4))
                .setFirstSelectedPosition(lastSelectedPosition)
                .initialise();
    }

    private void setFragment(int position){

    }


//**********************************************************************************
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            PreferenceUtils.setSignIn(MemberDetailsActivity.this,false);
            Intent intent = new Intent(MemberDetailsActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();

//            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_member) {

            //constraintLayout.setVisibility(View.INVISIBLE);
            linearLayout.setVisibility(View.GONE);
            bottomNavigationBar.setVisibility(View.GONE);
            viewPagerMember.setVisibility(View.GONE);
            MemberFragment memberFragment = MemberFragment.newInstance(list);
            FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction()
                    .setCustomAnimations(R.anim.anim_slide_in_from_left,
                            R.anim.anim_slide_out_from_left)
                    .replace(R.id.relativeLayout,
                            memberFragment,
                            memberFragment.getTag()).commit();
            Toast.makeText(MemberDetailsActivity.this, "Advertisement", Toast.LENGTH_SHORT).show();

        } else if (id == R.id.nav_events) {
            Intent intent = new Intent(MemberDetailsActivity.this,EventsActivity.class);
            startActivity(intent);

        } else if (id == R.id.nav_recording) {
            Intent intent = new Intent(MemberDetailsActivity.this,RecordingActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_setting) {
            Intent intent = new Intent(MemberDetailsActivity.this,MemberDetailsActivity.class);
            startActivity(intent);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    @Override
    protected void onRestart() {
        super.onRestart();
        finish();
        startActivity(getIntent());
    }

}
