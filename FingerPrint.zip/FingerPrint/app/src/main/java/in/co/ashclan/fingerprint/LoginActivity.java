package in.co.ashclan.fingerprint;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.ContentLoadingProgressBar;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.error.VolleyError;
import com.android.volley.request.SimpleMultiPartRequest;
import com.android.volley.toolbox.Volley;
import com.nostra13.universalimageloader.utils.L;

import net.gotev.uploadservice.MultipartUploadRequest;
import net.gotev.uploadservice.ServerResponse;
import net.gotev.uploadservice.UploadInfo;
import net.gotev.uploadservice.UploadServiceBroadcastReceiver;
import net.gotev.uploadservice.UploadStatusDelegate;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.ArrayList;
import java.util.UUID;

import in.co.ashclan.database.DataBaseHelper;
import in.co.ashclan.model.EventPOJO;
import in.co.ashclan.model.MemberPOJO;
import in.co.ashclan.utils.PreferenceUtils;

//import main.utils.PreferenceUtils;

public class LoginActivity extends AppCompatActivity {

    TextView textViewVersions;
    EditText editTextAdmin,editTextAdminPassword;
    Button buttonLogin;
    ContentLoadingProgressBar progressBar;
    ArrayList<MemberPOJO> memberList = new ArrayList<MemberPOJO>();
    ArrayList<EventPOJO> eventList = new ArrayList<EventPOJO>();

    DataBaseHelper dataBaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dataBaseHelper = new DataBaseHelper(this);
        Configuration config = getResources().getConfiguration();
        if (config.smallestScreenWidthDp >= 600)
        {
            setContentView(R.layout.activity_login_tablet);
        }
        else
        {
            setContentView(R.layout.activity_login);
        }
        init();
        login();
    }


    public void init(){
        textViewVersions = (TextView)findViewById(R.id.text_login_versions);
        editTextAdmin = (EditText)findViewById(R.id.admin);
        editTextAdminPassword = (EditText)findViewById(R.id.admin_password);
        buttonLogin = (Button)findViewById(R.id.button_login);
        progressBar = (ContentLoadingProgressBar)findViewById(R.id.progress_bar_login);
        editTextAdmin.setText(PreferenceUtils.getAdminName(LoginActivity.this));
        editTextAdminPassword.setText(PreferenceUtils.getAdminPassword(LoginActivity.this));

    }

    public void login(){
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean cancel = false;
                View focusView = null;

                if(TextUtils.isEmpty(editTextAdmin.getText())){
                    editTextAdmin.setError("This field is required");
                    focusView=editTextAdmin;
                    cancel=true;
                }

                if(TextUtils.isEmpty(editTextAdminPassword.getText())){
                    editTextAdminPassword.setError("This field is required");
                    focusView=editTextAdminPassword;
                    cancel=true;
                }

                if(cancel){
                    // There was an error; don't attempt login and focus the first
                    // form field with an error.
                    focusView.requestFocus();
                }else{
//                    sGetAccessToken(editTextAdmin.getText().toString(),editTextAdminPassword.getText().toString());
                    getAccessTokenVolley("http://52.172.221.235:8983/api/login",editTextAdmin.getText().toString(),editTextAdminPassword.getText().toString());

                }


            }
        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    //email=test@gmail.com
    //password=123456
    public void sGetAccessToken(final String email, final String password){
        final String uploadId = UUID.randomUUID().toString();

        try {
            MultipartUploadRequest multipartUploadRequest = new MultipartUploadRequest(this,uploadId,"http://52.172.221.235:8983/api/login");
            UploadServiceBroadcastReceiver uploadServiceBroadcastReceiver;

            multipartUploadRequest.addParameter("email",email)
                    .addParameter("password",password)
                    .setMaxRetries(2)
                    .setDelegate(new UploadStatusDelegate() {

                        @Override
                        public void onProgress(Context context, UploadInfo uploadInfo) {
                            progressBar.setVisibility(View.VISIBLE);
                        }

                        @Override
                        public void onError(Context context, UploadInfo uploadInfo, ServerResponse serverResponse, Exception exception) {

                        }

                        @Override
                        public void onCompleted(Context context, UploadInfo uploadInfo, ServerResponse serverResponse) {

                            JSONParser parser_obj = new JSONParser();
                            String token = null;
                            try {
                                JSONObject object = (JSONObject) parser_obj.parse(serverResponse.getBodyAsString());
                                token = (String)object.get("result");

                            } catch (ParseException e) {
                                e.printStackTrace();
                            }

                            if(token.equalsIgnoreCase("wrong email or password.")){
                                View focusView1,focusView2;
                                progressBar.setVisibility(View.INVISIBLE);
                                editTextAdmin.setError("wrong email");
                                focusView1=editTextAdmin;
                                editTextAdminPassword.setError("wrong password");
                                focusView2=editTextAdminPassword;
                                focusView1.requestFocus();
                                focusView2.requestFocus();
                            }else{
                                PreferenceUtils.setToken(LoginActivity.this,token);
                                PreferenceUtils.setAdminName(LoginActivity.this,email);
                                PreferenceUtils.setAdminPassword(LoginActivity.this,password);
                                PreferenceUtils.setSignIn(LoginActivity.this,true);

                                progressBar.setVisibility(View.INVISIBLE);
                                downloadMemberDetails(token);
                                Intent intent = new Intent(LoginActivity.this, DataLoadingActivity.class);
                                intent.putExtra("token", token);
                                startActivity(intent);
                                finish();

                            }
                            Toast.makeText(LoginActivity.this,token,Toast.LENGTH_LONG).show();
                        }
                        @Override
                        public void onCancelled(Context context, UploadInfo uploadInfo) {

                        }
                    })
                    .startUpload();

        }catch (Exception ex){
            ex.printStackTrace();
        }
    }
    public void downloadMemberDetails(String token){
        final String uploadId = UUID.randomUUID().toString();

        try {
            MultipartUploadRequest multipartUploadRequest = new MultipartUploadRequest(this,uploadId,"http://52.172.221.235:8983/api/get_all_members");
            UploadServiceBroadcastReceiver uploadServiceBroadcastReceiver;

            multipartUploadRequest.addParameter("token",token)
                    .setMaxRetries(2)
                    .setDelegate(new UploadStatusDelegate() {
                        @Override
                        public void onProgress(Context context, UploadInfo uploadInfo) {

                        }

                        @Override
                        public void onError(Context context, UploadInfo uploadInfo, ServerResponse serverResponse, Exception exception) {

                        }

                        @Override
                        public void onCompleted(Context context, UploadInfo uploadInfo, ServerResponse serverResponse) {

                            Toast.makeText(LoginActivity.this,serverResponse.getBodyAsString(),Toast.LENGTH_LONG).show();

                            JSONParser parser = new JSONParser();
                            JSONArray jsonArray = null;
                            try{
                                jsonArray = (JSONArray)parser.parse(serverResponse.getBodyAsString());

                                for(int i=0;i<jsonArray.size();i++){

                                    MemberPOJO member = new MemberPOJO();

                                    JSONObject object = (JSONObject)jsonArray.get(i);

                                    member.setId(String.valueOf(object.get("id")));
                                    member.setFirstName(object.get("first_name").toString());
                                    member.setLastName(object.get("last_name").toString());
                                    member.setGender(object.get("gender").toString());
                                    member.setStatus(object.get("status").toString());
                                    member.setMaritalStatus(object.get("marital_status").toString());
                                    member.setDob(object.get("dob").toString());
                                    member.setMobilePhone(object.get("mobile_phone").toString());
                                    member.setAddress(object.get("address").toString());
                                    member.setRollNo(object.get("No").toString());
                                    memberList.add(member);
                                }

                            } catch (ParseException e) {
                                e.printStackTrace();
                            }

                            Intent intent = new Intent(LoginActivity.this,HomeActivity.class);
                            intent.putExtra("member_list",memberList);
                            startActivity(intent);
                            finish();


                        }

                        @Override
                        public void onCancelled(Context context, UploadInfo uploadInfo) {

                        }
                    })

                    .startUpload();

        }catch (Exception ex){
            ex.printStackTrace();
        }
    }

    public void getAccessTokenVolley(String URL, final String email, final String password){
        SimpleMultiPartRequest smr = new SimpleMultiPartRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONParser parser_obj = new JSONParser();
                        String token = null;
                        try {
                            JSONObject object = (JSONObject) parser_obj.parse(response);
                            token = (String)object.get("result");
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        Toast.makeText(LoginActivity.this,token,Toast.LENGTH_SHORT).show();



                        if(token.equalsIgnoreCase("wrong email or password.")){
                                View focusView1,focusView2;
                                progressBar.setVisibility(View.INVISIBLE);
                                editTextAdmin.setError("wrong email");
                                focusView1=editTextAdmin;
                                editTextAdminPassword.setError("wrong password");
                                focusView2=editTextAdminPassword;
                                focusView1.requestFocus();
                                focusView2.requestFocus();
                            }else{
                                PreferenceUtils.setToken(LoginActivity.this,token);
                                PreferenceUtils.setAdminName(LoginActivity.this,email);
                                PreferenceUtils.setAdminPassword(LoginActivity.this,password);
                                PreferenceUtils.setSignIn(LoginActivity.this,true);

                                progressBar.setVisibility(View.INVISIBLE);
                                memberDetailsVolley("http://52.172.221.235:8983/api/get_all_members",PreferenceUtils.getToken(LoginActivity.this));

                            }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });


        smr.addStringParam("email",email)
                .addStringParam("password",password);

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(smr);

    }

    public void memberDetailsVolley(String URL, String token){
        SimpleMultiPartRequest smr = new SimpleMultiPartRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(LoginActivity.this,response,Toast.LENGTH_SHORT).show();
                        dataBaseHelper.deleteAllMembers();
                        JSONParser parser = new JSONParser();
                        JSONArray jsonArray = null;
                        try{
                            jsonArray = (JSONArray)parser.parse(response);

                            for(int i=0;i<jsonArray.size();i++){

                                MemberPOJO member = new MemberPOJO();

                                JSONObject object = (JSONObject)jsonArray.get(i);

                                member.setId(String.valueOf(object.get("id")));
                                member.setUserId(String.valueOf(object.get("user_id")));

                                member.setFirstName(isNull(object,"first_name"));
                                member.setMiddleName(isNull(object,"middle_name"));
                                member.setLastName(isNull(object,"last_name"));
                                member.setGender(isNull(object,"gender"));
                                member.setStatus(isNull(object,"status"));
                                member.setMaritalStatus(isNull(object,"marital_status"));
                                member.setDob(isNull(object,"dob"));
                                member.setHomePhone(isNull(object,"home_phone"));

                                member.setMobilePhone(isNull(object,"mobile_phone"));
                                member.setWorkPhone(isNull(object,"work_phone"));
                                member.setEmail(isNull(object,"email"));
                                member.setAddress(isNull(object,"address"));
                                member.setNotes(isNull(object,"notes"));
                                member.setRollNo(isNull(object,"No"));
                                member.setCreateAt(isNull(object,"created_at"));
                                member.setUpdateAt(isNull(object,"updated_at"));
                                member.setFingerPrint(isNull(object,"fingerprint"));


                                //remainber to do changes...
                                member.setPhotoURL(isNull(object,"photo",""));

                                memberList.add(member);
                                dataBaseHelper.insertMemberData(member);
                            }

                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        Intent intent = new Intent(LoginActivity.this,HomeActivity.class);
                        intent.putExtra("member_list",memberList);
                        startActivity(intent);
                        finish();

                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


            }
        });


        smr.addStringParam("token",token);

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(smr);
    }

    public void eventDetailsVolley(String URL,String token){

        SimpleMultiPartRequest smr = new SimpleMultiPartRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        dataBaseHelper.deleteAllEvents();
                        JSONParser parser = new JSONParser();
                        JSONArray jsonArray = null;
                        try{
                            jsonArray = (JSONArray)parser.parse(response);

                            for(int i=0;i<jsonArray.size();i++){

                                MemberPOJO member = new MemberPOJO();
                                EventPOJO event = new EventPOJO();
                                JSONObject object = (JSONObject)jsonArray.get(i);
                                event.setId(String.valueOf(object.get("id")));
                                event.setBranchId(isNull(object,"branch_id"));
                                event.setUserId(isNull(object,"user_id"));
                                event.setParentId(isNull(object,"parent_id"));
                                event.setEventLocationId(isNull(object,"event_location_id"));
                                event.setEventCalenderId(isNull(object,"event_calendar_id"));
                                event.setName(isNull(object,"name"));
                                event.setName(isNull(object,"cost"));
                                event.setAllDay(isNull(object,"all_day"));
                                event.setStartDate(isNull(object,"start_date"));
                                event.setStart_time(isNull(object,"start_time"));
                                event.setEnd_date(isNull(object,"end_date"));
                                event.setEnd_time(isNull(object,"end_time"));
                                event.setRecurring(isNull(object,"recurring"));
                                event.setRecurFrequency(isNull(object,"recur_frequency"));
                                event.setRecurStartDate(isNull(object,"recur_start_date"));
                                event.setRecurEndDate(isNull(object,"recur_end_date"));
                                event.setRecurNextDate(isNull(object,"recur_next_date"));
                                event.setRecurType(isNull(object,"recur_type"));
                                event.setCheckInType(isNull(object,"checkin_type"));
                                event.setTags(isNull(object,"tags"));
                                event.setIncludeCheckOut(isNull(object,"include_checkout"));
                                event.setFamilyCheckIn(isNull(object,"family_checkin"));
                                event.setFeatured_image(isNull(object,"featured_image"));
                                event.setGallery(isNull(object,"gallery"));
                                event.setFiles(isNull(object,"files"));
                                event.setYear(isNull(object,"year"));
                                event.setMonth(isNull(object,"month"));
                                event.setNotes(isNull(object,"notes"));
                                event.setCreatedAt(isNull(object,"created_at"));
                                event.setUpdatedAt(isNull(object,"updated_at"));
                                /*
                                "latitude": "",
                                "longitude": ""
                                */
                                eventList.add(event);
                                dataBaseHelper.insertEventData(event);

                            }

                        } catch (ParseException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        smr.addStringParam("token",token);
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(smr);
    }



    public String isNull(JSONObject object, String parma){
        return object.get(parma)!=null?object.get(parma).toString():"";
    }

    public String isNull(JSONObject object, String parma,String dafualtStr){
        return object.get(parma)!=null?object.get(parma).toString():dafualtStr;
    }




}

/*
    SimpleMultiPartRequest smr = new SimpleMultiPartRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        smr.addStringParam("token",token);
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(smr);
*/