package in.co.ashclan.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceUtils {

    public static final String PREFERENCE_KEY = "church";

    public static final String PREFERENCE_KEY_INTERNET_ACCESS="internetAccess";
    public static final String PREFERENCE_KEY_SIGN_IN="signIn";

    public static final String PREFERENCE_KEY_ADMIN_NAME = "adminName";
    public static final String PREFERENCE_KEY_ADMIN_PASSWORD = "adminPassword";
    public static final String PREFERENCE_KEY_TOKEN = "token";




    //prevent instantiation
    private PreferenceUtils(){}

    public static SharedPreferences getSharedPreferences(Context context){
        return context.getSharedPreferences(PREFERENCE_KEY,Context.MODE_PRIVATE);
    }

    public static void setInternetAccess(Context context,boolean internetAccess){
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putBoolean(PREFERENCE_KEY_INTERNET_ACCESS,internetAccess).apply();
    }

    public static boolean getInternetAccess(Context context){
        return getSharedPreferences(context).getBoolean(PREFERENCE_KEY_INTERNET_ACCESS,false);
    }

    public static void setSignIn(Context context,boolean signIn){
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putBoolean(PREFERENCE_KEY_SIGN_IN,signIn).apply();
    }

    public static boolean getSignIn(Context context){
        return getSharedPreferences(context).getBoolean(PREFERENCE_KEY_SIGN_IN,false);
    }

    public static void setAdminName(Context context,String adminName){
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putString(PREFERENCE_KEY_ADMIN_NAME,adminName).apply();
    }

    public static String getAdminName(Context context){
        return getSharedPreferences(context).getString(PREFERENCE_KEY_ADMIN_NAME,"");
    }

    public static void setAdminPassword(Context context,String adminPassword){
        SharedPreferences.Editor editor =getSharedPreferences(context).edit();
        editor.putString(PREFERENCE_KEY_ADMIN_PASSWORD,adminPassword).apply();
    }

    public static String getAdminPassword(Context context){
        return getSharedPreferences(context).getString(PREFERENCE_KEY_ADMIN_PASSWORD,"");
    }

    public static void setToken(Context context, String token){
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putString(PREFERENCE_KEY_TOKEN,token).apply();
    }

    public static String getToken(Context context){
        return getSharedPreferences(context).getString(PREFERENCE_KEY_TOKEN,"");
    }

}
