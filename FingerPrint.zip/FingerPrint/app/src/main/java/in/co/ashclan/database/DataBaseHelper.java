package in.co.ashclan.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import in.co.ashclan.model.EventPOJO;
import in.co.ashclan.model.MemberPOJO;

public class DataBaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "database.db";

    //Member Table
    public static final String MEMBERS_TABLE = "member_table";
    public static final String MEMBER_COl_1 = "member_id";
    public static final String MEMBER_COL_2 = "id";
    public static final String MEMBER_COL_3 = "user_id";
    public static final String MEMBER_COL_4 = "first_name";
    public static final String MEMBER_COL_5 = "middle_name";
    public static final String MEMBER_COL_6 = "last_name";
    public static final String MEMBER_COL_7 = "gender";
    public static final String MEMBER_COL_8 = "status";
    public static final String MEMBER_COL_9 = "marital_status";
    public static final String MEMBER_COL_10 = "dob";
    public static final String MEMBER_COL_11 = "home_phone";
    public static final String MEMBER_COL_12 = "mobile_phone";
    public static final String MEMBER_COL_13 = "work_phone";
    public static final String MEMBER_COL_14 = "email";
    public static final String MEMBER_COL_15 = "address";
    public static final String MEMBER_COL_16 = "notes";
    public static final String MEMBER_COL_17 = "photo_url";
    public static final String MEMBER_COL_18 = "photo_local_path";
    public static final String MEMBER_COL_19 = "fingerprint";
    public static final String MEMBER_COL_20 = "fingerprint1";
    public static final String MEMBER_COL_21 = "rollno";
    public static final String MEMBER_COL_22 = "created_at";
    public static final String MEMBER_COL_23 = "updated_at";

    public static final String CREATE_TABLE_MEMBER =
            "CREATE TABLE " + MEMBERS_TABLE + "("
                    + MEMBER_COl_1 + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + MEMBER_COL_2 + " TEXT,"
                    + MEMBER_COL_3 + " TEXT,"
                    + MEMBER_COL_4 + " TEXT,"
                    + MEMBER_COL_5 + " TEXT,"
                    + MEMBER_COL_6 + " TEXT,"
                    + MEMBER_COL_7 + " TEXT,"
                    + MEMBER_COL_8 + " TEXT,"
                    + MEMBER_COL_9 + " TEXT,"
                    + MEMBER_COL_10 + " TEXT,"
                    + MEMBER_COL_11 + " TEXT,"
                    + MEMBER_COL_12 + " TEXT,"
                    + MEMBER_COL_13 + " TEXT,"
                    + MEMBER_COL_14 + " TEXT,"
                    + MEMBER_COL_15 + " TEXT,"
                    + MEMBER_COL_16 + " TEXT,"
                    + MEMBER_COL_17 + " TEXT,"
                    + MEMBER_COL_18 + " TEXT,"
                    + MEMBER_COL_19 + " TEXT,"
                    + MEMBER_COL_20 + " TEXT,"
                    + MEMBER_COL_21 + " TEXT,"
                    + MEMBER_COL_22 + " TEXT,"
                    + MEMBER_COL_23 + " TEXT"
                    + ")";


    //Events Table
    public static final String EVENTS_TABLE = "event_table";
    public static final String EVENT_COl_1 = "event_id";
    public static final String EVENT_COL_2 = "id";
    public static final String EVENT_COL_30 = "branch_id";
    public static final String EVENT_COL_3 = "user_id";
    public static final String EVENT_COL_4 = "parent_id";
    public static final String EVENT_COL_5 = "event_location_id";
    public static final String EVENT_COL_6 = "event_calendar_id";
    public static final String EVENT_COL_7 = "name";
    public static final String EVENT_COL_8 = "cost";
    public static final String EVENT_COL_9 = "all_day";
    public static final String EVENT_COL_10 = "start_date";
    public static final String EVENT_COL_11= "start_time";
    public static final String EVENT_COL_31 = "end_date";
    public static final String EVENT_COL_12 = "end_time";
    public static final String EVENT_COL_13 = "recurring";
    public static final String EVENT_COL_14 = "recur_frequency";
    public static final String EVENT_COL_15 = "recu_start_date";
    public static final String EVENT_COL_16 = "recu_end_date";
    public static final String EVENT_COL_17 = "recur_next_date";
    public static final String EVENT_COL_18 = "recur_types";
    public static final String EVENT_COL_19 = "checkin_types";
    public static final String EVENT_COL_20 = "tags";
    public static final String EVENT_COL_21 = "include_checkout";
    public static final String EVENT_COL_22 = "family_checkin";
    public static final String EVENT_COL_23 = "featured_image";
    public static final String EVENT_COL_24 = "gallery";
    public static final String EVENT_COL_25 = "files";
    public static final String EVENT_COL_26 = "year";
    public static final String EVENT_COL_32 = "month";
    public static final String EVENT_COL_27 = "notes";
    public static final String EVENT_COL_28 = "created_at";
    public static final String EVENT_COL_29 = "updated_at";

    public static final String CREATE_TABLE_EVENTS =
            "CREATE TABLE " + EVENTS_TABLE + "("
                    + EVENT_COl_1 + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + EVENT_COL_2 + " TEXT,"
                    + EVENT_COL_3 + " TEXT,"
                    + EVENT_COL_4 + " TEXT,"
                    + EVENT_COL_5 + " TEXT,"
                    + EVENT_COL_6 + " TEXT,"
                    + EVENT_COL_7 + " TEXT,"
                    + EVENT_COL_8 + " TEXT,"
                    + EVENT_COL_9 + " TEXT,"
                    + EVENT_COL_10 + " TEXT,"
                    + EVENT_COL_11 + " TEXT,"
                    + EVENT_COL_12 + " TEXT,"
                    + EVENT_COL_13 + " TEXT,"
                    + EVENT_COL_14 + " TEXT,"
                    + EVENT_COL_15 + " TEXT,"
                    + EVENT_COL_16 + " TEXT,"
                    + EVENT_COL_17 + " TEXT,"
                    + EVENT_COL_18 + " TEXT,"
                    + EVENT_COL_19 + " TEXT,"
                    + EVENT_COL_20 + " TEXT,"
                    + EVENT_COL_21 + " TEXT,"
                    + EVENT_COL_22 + " TEXT,"
                    + EVENT_COL_23 + " TEXT,"
                    + EVENT_COL_24 + " TEXT,"
                    + EVENT_COL_25 + " TEXT,"
                    + EVENT_COL_26 + " TEXT,"
                    + EVENT_COL_27 + " TEXT,"
                    + EVENT_COL_28 + " TEXT,"
                    + EVENT_COL_29 + " TEXT,"
                    + EVENT_COL_30 + " TEXT,"
                    + EVENT_COL_31 + " TEXT,"
                    + EVENT_COL_32 + " TEXT"
                    + ")";

    public DataBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //Create tables
        db.execSQL(CREATE_TABLE_MEMBER);
        db.execSQL(CREATE_TABLE_EVENTS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

        //Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + MEMBERS_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + EVENTS_TABLE);

        // Create tables again
        onCreate(db);
    }

    //Members
    public boolean insertMemberData(MemberPOJO member) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(MEMBER_COL_2,member.getId());
        values.put(MEMBER_COL_3,member.getUserId());
        values.put(MEMBER_COL_4,member.getFirstName());
        values.put(MEMBER_COL_5,member.getMiddleName());
        values.put(MEMBER_COL_6,member.getLastName());
        values.put(MEMBER_COL_7,member.getGender());
        values.put(MEMBER_COL_8,member.getStatus());
        values.put(MEMBER_COL_9,member.getMaritalStatus());
        values.put(MEMBER_COL_10,member.getDob());
        values.put(MEMBER_COL_11,member.getHomePhone());
        values.put(MEMBER_COL_12,member.getMobilePhone());
        values.put(MEMBER_COL_13,member.getWorkPhone());
        values.put(MEMBER_COL_14,member.getEmail());
        values.put(MEMBER_COL_15,member.getAddress());
        values.put(MEMBER_COL_16,member.getNotes());
        values.put(MEMBER_COL_17,member.getPhotoURL());
        values.put(MEMBER_COL_18,member.getPhotoLocalPath());
        values.put(MEMBER_COL_19,member.getFingerPrint());
        values.put(MEMBER_COL_20,member.getFingerPrint1());
        values.put(MEMBER_COL_21,member.getRollNo());
        values.put(MEMBER_COL_22,member.getCreateAt());
        values.put(MEMBER_COL_23,member.getUpdateAt());

        long result = db.insert(MEMBERS_TABLE,null,values);

        db.close();
        if(result==-1){
            return false;
        }else {
            return true;
        }
    }
    public List<MemberPOJO> getAllMembers(){

        List<MemberPOJO> members = new ArrayList<MemberPOJO>();

        String selectQuery = "SELECT  * FROM " + MEMBERS_TABLE;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery,null);

        //looping through all row and adding to list
        if (cursor.moveToFirst()){
            do {

                MemberPOJO member = new MemberPOJO();
                member.setId(cursor.getString(cursor.getColumnIndex(MEMBER_COL_2)));
                member.setUserId(cursor.getString(cursor.getColumnIndex(MEMBER_COL_3)));
                member.setFirstName(cursor.getString(cursor.getColumnIndex(MEMBER_COL_4)));
                member.setMiddleName(cursor.getString(cursor.getColumnIndex(MEMBER_COL_5)));
                member.setLastName(cursor.getString(cursor.getColumnIndex(MEMBER_COL_6)));
                member.setGender(cursor.getString(cursor.getColumnIndex(MEMBER_COL_7)));
                member.setStatus(cursor.getString(cursor.getColumnIndex(MEMBER_COL_8)));
                member.setMaritalStatus(cursor.getString(cursor.getColumnIndex(MEMBER_COL_9)));
                member.setDob(cursor.getString(cursor.getColumnIndex(MEMBER_COL_10)));
                member.setHomePhone(cursor.getString(cursor.getColumnIndex(MEMBER_COL_11)));
                member.setMobilePhone(cursor.getString(cursor.getColumnIndex(MEMBER_COL_12)));
                member.setWorkPhone(cursor.getString(cursor.getColumnIndex(MEMBER_COL_13)));
                member.setEmail(cursor.getString(cursor.getColumnIndex(MEMBER_COL_14)));
                member.setAddress(cursor.getString(cursor.getColumnIndex(MEMBER_COL_15)));
                member.setNotes(cursor.getString(cursor.getColumnIndex(MEMBER_COL_16)));
                member.setPhotoURL(cursor.getString(cursor.getColumnIndex(MEMBER_COL_17)));
                member.setPhotoLocalPath(cursor.getString(cursor.getColumnIndex(MEMBER_COL_18)));
                member.setFingerPrint(cursor.getString(cursor.getColumnIndex(MEMBER_COL_19)));
                member.setFingerPrint1(cursor.getString(cursor.getColumnIndex(MEMBER_COL_20)));
                member.setRollNo(cursor.getString(cursor.getColumnIndex(MEMBER_COL_21)));
                member.setCreateAt(cursor.getString(cursor.getColumnIndex(MEMBER_COL_22)));
                member.setUpdateAt(cursor.getString(cursor.getColumnIndex(MEMBER_COL_23)));

                members.add(member);
            }while (cursor.moveToNext());
        }
        db.close();
        return members;
    }
    public void deleteAllMembers(){
       try {
           String selectQuery = "DELETE FROM " + MEMBERS_TABLE;
           SQLiteDatabase db = this.getWritableDatabase();
           db.delete(MEMBERS_TABLE, null, null);
           db.close();
       }catch (Exception ex){
           ex.printStackTrace();
           Log.e("Member Delete-->",ex.toString());
       }
    }

    //Events
    public boolean insertEventData(EventPOJO event){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(EVENT_COL_2,event.getId());
        values.put(EVENT_COL_3,event.getUserId());
        values.put(EVENT_COL_4,event.getParentId());
        values.put(EVENT_COL_5,event.getEventLocationId());
        values.put(EVENT_COL_6,event.getEventCalenderId());
        values.put(EVENT_COL_7,event.getName());
        values.put(EVENT_COL_8,event.getCost());
        values.put(EVENT_COL_9,event.getAllDay());
        values.put(EVENT_COL_10,event.getStartDate());
        values.put(EVENT_COL_11,event.getStart_time());
        values.put(EVENT_COL_12,event.getEnd_time());
        values.put(EVENT_COL_13,event.getRecurring());
        values.put(EVENT_COL_14,event.getRecurFrequency());
        values.put(EVENT_COL_15,event.getRecurStartDate());
        values.put(EVENT_COL_16,event.getRecurEndDate());
        values.put(EVENT_COL_17,event.getRecurNextDate());
        values.put(EVENT_COL_18,event.getRecurType());
        values.put(EVENT_COL_19,event.getCheckInType());
        values.put(EVENT_COL_20,event.getTags());
        values.put(EVENT_COL_21,event.getIncludeCheckOut());
        values.put(EVENT_COL_22,event.getFamilyCheckIn());
        values.put(EVENT_COL_23,event.getFeatured_image());
        values.put(EVENT_COL_24,event.getGallery());
        values.put(EVENT_COL_25,event.getFiles());
        values.put(EVENT_COL_26,event.getYear());
        values.put(EVENT_COL_27,event.getNotes());
        values.put(EVENT_COL_28,event.getCreatedAt());
        values.put(EVENT_COL_29,event.getUpdatedAt());
        values.put(EVENT_COL_30,event.getBranchId());
        values.put(EVENT_COL_31,event.getEnd_date());
        values.put(EVENT_COL_32,event.getMonth());

        long result = db.insert(EVENTS_TABLE,null,values);

        db.close();
        if(result==-1){
            return false;
        }else {
            return true;
        }
    }
    public List<EventPOJO> getAllEvent(){

        List<EventPOJO> events = new ArrayList<EventPOJO>();
        String selectQuery = "SELECT  * FROM " + EVENTS_TABLE;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery,null);

        //looping through all row and adding to list
        if (cursor.moveToFirst()){
            do {

                EventPOJO event = new EventPOJO();

                event.setId(cursor.getString(cursor.getColumnIndex(EVENT_COL_2)));
                event.setUserId(cursor.getString(cursor.getColumnIndex(EVENT_COL_3)));
                event.setParentId(cursor.getString(cursor.getColumnIndex(EVENT_COL_4)));
                event.setEventLocationId(cursor.getString(cursor.getColumnIndex(EVENT_COL_5)));
                event.setEventCalenderId(cursor.getString(cursor.getColumnIndex(EVENT_COL_6)));
                event.setName(cursor.getString(cursor.getColumnIndex(EVENT_COL_7)));
                event.setCost(cursor.getString(cursor.getColumnIndex(EVENT_COL_8)));
                event.setAllDay(cursor.getString(cursor.getColumnIndex(EVENT_COL_9)));
                event.setStartDate(cursor.getString(cursor.getColumnIndex(EVENT_COL_10)));
                event.setStart_time(cursor.getString(cursor.getColumnIndex(EVENT_COL_11)));
                event.setEnd_time(cursor.getString(cursor.getColumnIndex(EVENT_COL_12)));
                event.setRecurring(cursor.getString(cursor.getColumnIndex(EVENT_COL_13)));
                event.setRecurFrequency(cursor.getString(cursor.getColumnIndex(EVENT_COL_14)));
                event.setRecurStartDate(cursor.getString(cursor.getColumnIndex(EVENT_COL_15)));
                event.setRecurEndDate(cursor.getString(cursor.getColumnIndex(EVENT_COL_16)));
                event.setRecurNextDate(cursor.getString(cursor.getColumnIndex(EVENT_COL_17)));
                event.setRecurType(cursor.getString(cursor.getColumnIndex(EVENT_COL_18)));
                event.setCheckInType(cursor.getString(cursor.getColumnIndex(EVENT_COL_19)));
                event.setTags(cursor.getString(cursor.getColumnIndex(EVENT_COL_20)));
                event.setIncludeCheckOut(cursor.getString(cursor.getColumnIndex(EVENT_COL_21)));
                event.setFamilyCheckIn(cursor.getString(cursor.getColumnIndex(EVENT_COL_22)));
                event.setFeatured_image(cursor.getString(cursor.getColumnIndex(EVENT_COL_23)));
                event.setGallery(cursor.getString(cursor.getColumnIndex(EVENT_COL_24)));
                event.setFiles(cursor.getString(cursor.getColumnIndex(EVENT_COL_25)));
                event.setYear(cursor.getString(cursor.getColumnIndex(EVENT_COL_26)));
                event.setNotes(cursor.getString(cursor.getColumnIndex(EVENT_COL_27)));
                event.setCreatedAt(cursor.getString(cursor.getColumnIndex(EVENT_COL_28)));
                event.setUpdatedAt(cursor.getString(cursor.getColumnIndex(EVENT_COL_29)));
                event.setBranchId(cursor.getString(cursor.getColumnIndex(EVENT_COL_30)));
                event.setEnd_date(cursor.getString(cursor.getColumnIndex(EVENT_COL_31)));
                event.setMonth(cursor.getString(cursor.getColumnIndex(EVENT_COL_32)));

                events.add(event);
            }while (cursor.moveToNext());
        }
        db.close();
        return events;
    }
    public void deleteAllEvents(){
        try {
            String selectQuery = "DELETE FROM " + EVENTS_TABLE;
            SQLiteDatabase db = this.getWritableDatabase();
            db.delete(EVENTS_TABLE, null, null);
            db.close();
        }catch (Exception ex){
            ex.printStackTrace();
            Log.e("Event Delete-->",ex.toString());
        }
    }



}
