package in.co.ashclan.fingerprint;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

//import com.android.volley.Request;
//import com.android.volley.RequestQueue;
//import com.android.volley.Response;
//import com.android.volley.VolleyError;
//import com.android.volley.request.SimpleMultiPartRequest;
//import com.android.volley.toolbox.Volley;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.error.VolleyError;
import com.android.volley.request.SimpleMultiPartRequest;
import com.android.volley.toolbox.Volley;

import net.gotev.uploadservice.MultipartUploadRequest;
import net.gotev.uploadservice.ServerResponse;
import net.gotev.uploadservice.UploadInfo;
import net.gotev.uploadservice.UploadServiceBroadcastReceiver;
import net.gotev.uploadservice.UploadStatusDelegate;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import android_serialport_api.AsyncFingerprint;
import android_serialport_api.AsyncFingerprintA5;
import android_serialport_api.SerialPortManager;
import android_serialport_api.SerialPortManagerA5;
import fr.ganfra.materialspinner.MaterialSpinner;
import in.co.ashclan.database.DataBaseHelper;
import in.co.ashclan.model.MemberPOJO;
import in.co.ashclan.utils.PreferenceUtils;
import in.co.ashclan.utils.Utility;
import in.co.ashclan.utils.WebServiceCall;

import static java.security.AccessController.getContext;

public class MemberRegisterActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText editTextFirstName,editTextMiddleName,editTextLastname,editTextEmail,editTextHomePhone,
            editTextMobilePhone,editTextWorkPhone,editTextDOB,editTextAddress,editTextDescription;
    private ImageView imageViewFingerPrint1,imageViewFingerPrint2;
    private MaterialSpinner msGender,msMartialStatus,msStatus;
    private Button buttonSubmit;
    private ProgressBar progressBar;

    private byte[] model1=new byte[512];
    private byte[] model2=new byte[512];
    private boolean isEnroll1=false;
    private boolean isEnroll2=false;

    private boolean isTablet=false;
    private boolean isPhone=false;

    private AsyncFingerprint registerFingerprint;
    private AsyncFingerprintA5 registerFingerprintA5;

    private Dialog fpDialog=null;
    private int iFinger=0;
    private int count;

    private ImageView fpImage;
    private TextView fpStatusText;
    private SharedPreferences perfs;
    DataBaseHelper dataBase;

    private boolean bcheck=false;
    private boolean	bIsUpImage=true;
    private boolean	bIsCancel=false;

    List<MemberPOJO> list = new ArrayList<MemberPOJO>();
    MemberPOJO memberDetails = new MemberPOJO();

    private String fpStrByte1,fpStrByte2;
    private byte[] fpByte1;
    private byte[] fpByte2;
    private int mYear, mMonth, mDay;


    //****Camera****
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    private String userChoosenTask;
    private Bitmap bitmapImage;
    private File destination;
    private String imagePath;

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member_register);
        inits();
        Configuration config = getResources().getConfiguration();
        if (config.smallestScreenWidthDp >= 600)
        {
            Toast.makeText(MemberRegisterActivity.this,"Tablet",Toast.LENGTH_LONG).show();
            isTablet=true;
            registerFingerprint = SerialPortManager.getInstance().getNewAsyncFingerprint();
            FPInitFP07();

            //temp
//            FPInitA5();
        }
        else
        {
            Toast.makeText(MemberRegisterActivity.this,"Phone",Toast.LENGTH_LONG).show();
            isPhone=true;
            registerFingerprintA5 = SerialPortManagerA5.getInstance().getNewAsyncFingerprint();
            FPInitA5();
        }
    }

    public void inits(){
        editTextFirstName=(EditText)findViewById(R.id.first_name);
        editTextMiddleName=(EditText)findViewById(R.id.middle_name);
        editTextLastname=(EditText)findViewById(R.id.last_name);
        editTextEmail=(EditText)findViewById(R.id.email);
        editTextHomePhone=(EditText)findViewById(R.id.home_phone);
        editTextMobilePhone=(EditText)findViewById(R.id.mobile_phone);
        editTextWorkPhone=(EditText)findViewById(R.id.work_phone);
        editTextDOB=(EditText)findViewById(R.id.dob);
        editTextAddress=(EditText)findViewById(R.id.address);
        editTextDescription=(EditText)findViewById(R.id.description);

        imageViewFingerPrint1=(ImageView)findViewById(R.id.imageView1);
        imageViewFingerPrint2=(ImageView)findViewById(R.id.imageView2);

        msGender=(MaterialSpinner)findViewById(R.id.spinner_gender);
        msMartialStatus=(MaterialSpinner)findViewById(R.id.spinner_martial_status);
        msStatus=(MaterialSpinner)findViewById(R.id.spinner_status);

        buttonSubmit=(Button)findViewById(R.id.button_submit);

        progressBar=(ProgressBar)findViewById(R.id.progress_bar_member_register);

        imageViewFingerPrint1.setOnClickListener(this);
        imageViewFingerPrint2.setOnClickListener(this);
        editTextDOB.setOnClickListener(this);
        buttonSubmit.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        if (view==imageViewFingerPrint1){
            FPDialog(1);
        }
        if (view==imageViewFingerPrint2){
            selectImage();
        }
        if (view==editTextDOB){
            dateDialog();
        }
        if (view==buttonSubmit){
            submitMemberRegistration();
        }
    }

    private void dateDialog(){
        // Get Current Date
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);



        DatePickerDialog datePickerDialog = new DatePickerDialog(this,R.style.DialogTheme,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        editTextDOB.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);

                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

    public void FPDialog(int i){
        iFinger = i;
        AlertDialog.Builder builder = new AlertDialog.Builder(MemberRegisterActivity.this);
        builder.setTitle("Registration FingerPrint");
        final LayoutInflater inflater = LayoutInflater.from(MemberRegisterActivity.this);
        View dialogView = inflater.inflate(R.layout.dialog_enrolfinger,null);
        fpImage = (ImageView) dialogView.findViewById(R.id.dialog_image);
        fpStatusText = (TextView) dialogView.findViewById(R.id.dialog_text);
        builder.setView(dialogView);
        builder.setCancelable(false);
     /*   builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
       */
        builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                dialogInterface.dismiss();
            }
        });
        fpDialog = builder.create();
        fpDialog.setCanceledOnTouchOutside(false);
        fpDialog.show();

        FPProcess();

    }

    public void FPProcess(){
        count=1;
        fpStatusText.setText("Please Press Finger");
        try {
            Thread.currentThread();
            Thread.sleep(200);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        if(isPhone) {
            registerFingerprintA5.FP_GetImage();
        }else if(isTablet){
            registerFingerprint.FP_GetImage();
        }
    }

    private void FPInitA5() {

        registerFingerprintA5.setOnGetImageListener(new AsyncFingerprintA5.OnGetImageListener() {
            @Override
            public void onGetImageSuccess() {
                if (!bIsCancel) {
                    if (bcheck) {
                        registerFingerprintA5.FP_GetImage();
                    } else {
                        if (bIsUpImage) {
                            registerFingerprintA5.FP_UpImage();
                            fpStatusText.setText(getString(R.string.txt_fpdisplay));
                        } else {
                            fpStatusText.setText(getString(R.string.txt_fpprocess));
                            registerFingerprintA5.FP_GenChar(count);
                        }
                    }
                }
            }

            @Override
            public void onGetImageFail() {
                if (!bIsCancel) {
                    if (bcheck) {
                        bcheck = false;
                        fpStatusText.setText(getString(R.string.txt_fpplace));
                        registerFingerprintA5.FP_GetImage();
                        count++;
                    } else {
                        registerFingerprintA5.FP_GetImage();
                    }
                }
            }
        });

        registerFingerprintA5.setOnUpImageListener(new AsyncFingerprintA5.OnUpImageListener() {
            @Override
            public void onUpImageSuccess(byte[] data) {
                Bitmap image = BitmapFactory.decodeByteArray(data, 0, data.length);
                fpImage.setImageBitmap(image);
                //fpImage.setBackgroundDrawable(new BitmapDrawable(image));
                registerFingerprintA5.FP_GenChar(count);
                fpStatusText.setText(getString(R.string.txt_fpprocess));
            }

            @Override
            public void onUpImageFail() {
            }
        });

        registerFingerprintA5.setOnGenCharListener(new AsyncFingerprintA5.OnGenCharListener() {
            @Override
            public void onGenCharSuccess(int bufferId) {
                if (bufferId == 1) {
                    bcheck = true;
                    fpStatusText.setText(getString(R.string.txt_fplift));
                    registerFingerprintA5.FP_GetImage();
                } else if (bufferId == 2) {
                    registerFingerprintA5.FP_RegModel();
                }
            }

            @Override
            public void onGenCharFail() {
                fpStatusText.setText(getString(R.string.txt_fpfail));
            }
        });

        registerFingerprintA5.setOnRegModelListener(new AsyncFingerprintA5.OnRegModelListener() {

            @Override
            public void onRegModelSuccess() {
                registerFingerprintA5.FP_UpChar();
                fpStatusText.setText(getString(R.string.txt_fpenrolok));
            }

            @Override
            public void onRegModelFail() {
                fpStatusText.setText(getString(R.string.txt_fpenrolfail)+"2");
                fpDialog.cancel();

            }
        });

        registerFingerprintA5.setOnUpCharListener(new AsyncFingerprintA5.OnUpCharListener() {

            @Override
            public void onUpCharSuccess(byte[] model) {

                if (iFinger == 1) {
                    imageViewFingerPrint1.setColorFilter(getResources().getColor(R.color.green));
                    System.arraycopy(model, 0, MemberRegisterActivity.this.model1, 0, 512);
                    isEnroll1 = true;
                } else {
                    imageViewFingerPrint2.setColorFilter(getResources().getColor(R.color.green));

                    System.arraycopy(model, 0, MemberRegisterActivity.this.model2, 0, 512);
                    isEnroll2 = true;
                }
                fpStatusText.setText(getString(R.string.txt_fpenrolok));
                fpDialog.cancel();
            }

            @Override
            public void onUpCharFail() {
                fpStatusText.setText(getString(R.string.txt_fpenrolfail));
                fpDialog.cancel();
            }
        });
    }

    private void FPInitFP07() {

        registerFingerprint.setOnGetImageListener(new AsyncFingerprint.OnGetImageListener() {
            @Override
            public void onGetImageSuccess() {
                if (!bIsCancel) {
                    if (bcheck) {
                        registerFingerprint.FP_GetImage();
                    } else {
                        if (bIsUpImage) {
                            registerFingerprint.FP_UpImage();
                            fpStatusText.setText(getString(R.string.txt_fpdisplay));
                        } else {
                            fpStatusText.setText(getString(R.string.txt_fpprocess));
                            registerFingerprint.FP_GenChar(count);
                        }
                    }
                }
            }

            @Override
            public void onGetImageFail() {
                if (!bIsCancel) {
                    if (bcheck) {
                        bcheck = false;
                        fpStatusText.setText(getString(R.string.txt_fpplace));
                        registerFingerprint.FP_GetImage();
                        count++;
                    } else {
                        registerFingerprint.FP_GetImage();
                    }
                }
            }
        });

        registerFingerprint.setOnUpImageListener(new AsyncFingerprint.OnUpImageListener() {
            @Override
            public void onUpImageSuccess(byte[] data) {
                Bitmap image = BitmapFactory.decodeByteArray(data, 0, data.length);
                fpImage.setImageBitmap(image);
                //fpImage.setBackgroundDrawable(new BitmapDrawable(image));
                registerFingerprint.FP_GenChar(count);
                fpStatusText.setText(getString(R.string.txt_fpprocess));
            }

            @Override
            public void onUpImageFail() {
            }
        });

        registerFingerprint.setOnGenCharListener(new AsyncFingerprint.OnGenCharListener() {
            @Override
            public void onGenCharSuccess(int bufferId) {
                if (bufferId == 1) {
                    bcheck = true;
                    fpStatusText.setText(getString(R.string.txt_fplift));
                    registerFingerprint.FP_GetImage();
                } else if (bufferId == 2) {
                    registerFingerprint.FP_RegModel();
                }
            }

            @Override
            public void onGenCharFail() {
                fpStatusText.setText(getString(R.string.txt_fpfail));
            }
        });

        registerFingerprint.setOnRegModelListener(new AsyncFingerprint.OnRegModelListener() {

            @Override
            public void onRegModelSuccess() {
                registerFingerprint.FP_UpChar();
                fpStatusText.setText(getString(R.string.txt_fpenrolok));
            }

            @Override
            public void onRegModelFail() {
                fpStatusText.setText(getString(R.string.txt_fpenrolfail)+"2");
                fpDialog.cancel();

            }
        });

        registerFingerprint.setOnUpCharListener(new AsyncFingerprint.OnUpCharListener() {

            @Override
            public void onUpCharSuccess(byte[] model) {

                if (iFinger == 1) {
                    imageViewFingerPrint1.setColorFilter(getResources().getColor(R.color.green));
                    System.arraycopy(model, 0, MemberRegisterActivity.this.model1, 0, 512);
                    isEnroll1 = true;
                } else {
                    imageViewFingerPrint2.setColorFilter(getResources().getColor(R.color.green));

                    System.arraycopy(model, 0, MemberRegisterActivity.this.model2, 0, 512);
                    isEnroll2 = true;
                }
                fpStatusText.setText(getString(R.string.txt_fpenrolok));
                fpDialog.cancel();
            }

            @Override
            public void onUpCharFail() {
                fpStatusText.setText(getString(R.string.txt_fpenrolfail));
                fpDialog.cancel();
            }
        });
    }


    public boolean utilsCheck(){

        boolean cancel = false;
        View focusView = null;
        if (TextUtils.isEmpty(editTextFirstName.getText())){
            editTextFirstName.setError("Please enter first Name");
            focusView=editTextFirstName;
            cancel=true;
        }

        if (TextUtils.isEmpty(editTextLastname.getText())){
            editTextLastname.setError("Please enter Last Name");
            focusView=editTextLastname;
            cancel=true;
        }
        if (TextUtils.isEmpty(editTextEmail.getText())){
            editTextEmail.setError("Please enter Email");
            focusView=editTextEmail;
            cancel=true;
        }
        if (TextUtils.isEmpty(editTextHomePhone.getText())){
            editTextHomePhone.setError("Please enter Home Phone");
            focusView=editTextHomePhone;
            cancel=true;
        }
        if (TextUtils.isEmpty(editTextMobilePhone.getText())){
            editTextMobilePhone.setError("Please enter Mobile Phone");
            focusView=editTextMobilePhone;
            cancel=true;
        }
        if (TextUtils.isEmpty(editTextWorkPhone.getText())){
            editTextWorkPhone.setError("Please enter Work Phone");
            focusView=editTextWorkPhone;
            cancel=true;
        }

        if (TextUtils.isEmpty(editTextDOB.getText())&&!isValidDate(editTextDOB.getText().toString())){
            editTextDOB.setError("Please enter in dateformat");
            focusView=editTextDOB;
            cancel=true;
        }
        if(msGender.getSelectedItemPosition()==0){
            msGender.setError("Please Select Gender");
            focusView=msGender;
            cancel=true;
        }
        if(msMartialStatus.getSelectedItemPosition()==0){
            msMartialStatus.setError("Please Select Martial status");
            focusView=msMartialStatus;
            cancel=true;
        }
        if(msStatus.getSelectedItemPosition()==0){
            msStatus.setError("Please Select Status");
            focusView=msStatus;
            cancel=true;
        }


        if(!isEnroll1){
            imageViewFingerPrint1.setColorFilter(getResources().getColor(R.color.red));
            cancel=true;
        }
        if(getImagePath()==""||getImagePath()==null){
            imageViewFingerPrint2.setBackgroundColor(getResources().getColor(R.color.red));
            cancel=true;
        }


        return cancel;
    }

    private boolean isEmailValid(String email) {
        return email.contains("@");
    }
    public static boolean isValidDate(String inDate) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(inDate.trim());
        } catch (ParseException pe) {
            return false;
        }
        return true;
    }
    public void submitMemberRegistration(){

        if (utilsCheck()){

        }else {
            memberDetails.setFirstName(editTextFirstName.getText().toString());
            memberDetails.setLastName(editTextLastname.getText().toString());
            memberDetails.setMiddleName(editTextMiddleName.getText().toString());
            memberDetails.setEmail(editTextEmail.getText().toString());
            memberDetails.setGender(msGender.getSelectedItem().toString());//check out onces
            memberDetails.setMaritalStatus(msMartialStatus.getSelectedItem().toString());
            memberDetails.setStatus(msStatus.getSelectedItem().toString());
            memberDetails.setHomePhone(editTextHomePhone.getText().toString());
            memberDetails.setMobilePhone(editTextMobilePhone.getText().toString());
            memberDetails.setWorkPhone(editTextWorkPhone.getText().toString());
            memberDetails.setDob(editTextAddress.getText().toString());
            memberDetails.setAddress(editTextAddress.getText().toString());
            memberDetails.setNotes(editTextDescription.getText().toString());
            memberDetails.setDob(editTextDOB.getText().toString());

            if (isEnroll1) {
                fpByte1 = new byte[model1.length];
                System.arraycopy(model1, 0, fpByte1, 0, model1.length);
                fpStrByte1 = Base64.encodeToString(fpByte1, Base64.DEFAULT);
                imageViewFingerPrint1.setColorFilter(getResources().getColor(R.color.green));
            }



            if (isEnroll2) {
                fpByte2 = new byte[model2.length];
                System.arraycopy(model2, 0, fpByte2, 0, model2.length);
                fpStrByte2 = Base64.encodeToString(fpByte2, Base64.DEFAULT);
                imageViewFingerPrint2.setColorFilter(getResources().getColor(R.color.green));
            }
            memberDetails.setFingerPrint(fpStrByte1);
            memberDetails.setFingerPrint1(fpStrByte2);
            progressBar.setVisibility(View.VISIBLE);
        //    uploadMemberDataInServer("http://52.172.221.235:8983/api/create_member",memberDetails,true);
            memberRegisterVolley("http://52.172.221.235:8983/api/create_member",memberDetails);
        }
    }

    public void uploadMemberDataInServer(String serverURL, MemberPOJO memberDetails, final boolean check){
        final String uploadId = UUID.randomUUID().toString();

        try {
            MultipartUploadRequest multipartUploadRequest = new MultipartUploadRequest(MemberRegisterActivity.this,uploadId,
                            "http://52.172.221.235:8983/api/create_member");
            UploadServiceBroadcastReceiver uploadServiceBroadcastReceiver;


            multipartUploadRequest.addFileToUpload(getImagePath(), "photo") //Adding file
                    .addParameter("token", PreferenceUtils.getToken(MemberRegisterActivity.this))
                    .addParameter("first_name",memberDetails.getFirstName())
                    .addParameter("middle_name",memberDetails.getMiddleName())
                    .addParameter("last_name",memberDetails.getLastName())
                    .addParameter("gender",memberDetails.getGender())
                    .addParameter("marital_status",memberDetails.getMaritalStatus())
                    .addParameter("status",memberDetails.getStatus())
                    .addParameter("mobile_phone",memberDetails.getMobilePhone())
                    .addParameter("dob",memberDetails.getDob())
                    .addParameter("address",memberDetails.getAddress())
                    .addParameter("fingerprint",memberDetails.getFingerPrint())
                    .addParameter("home_phone",memberDetails.getHomePhone())
                    .addParameter("work_phone",memberDetails.getWorkPhone())
                    .addParameter("email",memberDetails.getEmail())
                    .addParameter("notes",memberDetails.getNotes())
                    .addParameter("fingerprint_1","")
                    .setMaxRetries(2)
                    .setDelegate(new UploadStatusDelegate() {
                        @Override
                        public void onProgress(Context context, UploadInfo uploadInfo) {

                        }

                        @Override
                        public void onError(Context context, UploadInfo uploadInfo, ServerResponse serverResponse, Exception exception) {
                            Toast.makeText(MemberRegisterActivity.this,serverResponse.getBodyAsString(),Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onCompleted(Context context, UploadInfo uploadInfo, ServerResponse serverResponse) {

                            Toast.makeText(MemberRegisterActivity.this,serverResponse.getBodyAsString(),Toast.LENGTH_LONG).show();
                            if (check) {
                                Toast.makeText(MemberRegisterActivity.this, "Saved successfully", Toast.LENGTH_SHORT).show();
                                if (isPhone){
                                    SerialPortManagerA5.getInstance().closeSerialPort();
                                    finish();
                                    progressBar.setVisibility(View.INVISIBLE);

                                }
                                if (isTablet) {
                                    SerialPortManager.getInstance().closeSerialPort();
                                    finish();
                                    progressBar.setVisibility(View.INVISIBLE);
                                }

                            }
                        }

                        @Override
                        public void onCancelled(Context context, UploadInfo uploadInfo) {
                            Toast.makeText(MemberRegisterActivity.this,"onCancelled",Toast.LENGTH_SHORT).show();
                        }
                    }).startUpload();

        }catch (Exception ex){
            progressBar.setVisibility(View.INVISIBLE);

            ex.printStackTrace();
        }
    }

    public void memberRegisterVolley(String URL,MemberPOJO memberDetails){
        SimpleMultiPartRequest smr = new SimpleMultiPartRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(MemberRegisterActivity.this,response,Toast.LENGTH_SHORT).show();

                        if (isPhone){
                            SerialPortManagerA5.getInstance().closeSerialPort();
                            finish();
                            progressBar.setVisibility(View.INVISIBLE);

                        }
                        if (isTablet) {
                            SerialPortManager.getInstance().closeSerialPort();
                            finish();
                            progressBar.setVisibility(View.INVISIBLE);
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


            }
        });

        smr.addFile("photo",getImagePath())
                .addStringParam("token", PreferenceUtils.getToken(MemberRegisterActivity.this))
                .addStringParam("first_name",memberDetails.getFirstName())
                .addStringParam("middle_name",memberDetails.getMiddleName())
                .addStringParam("last_name",memberDetails.getLastName())
                .addStringParam("gender",memberDetails.getGender())
                .addStringParam("marital_status",memberDetails.getMaritalStatus())
                .addStringParam("status",memberDetails.getStatus())
                .addStringParam("mobile_phone",memberDetails.getMobilePhone())
                .addStringParam("dob",memberDetails.getDob())
                .addStringParam("address",memberDetails.getAddress())
                .addStringParam("fingerprint",memberDetails.getFingerPrint())
                .addStringParam("home_phone",memberDetails.getHomePhone())
                .addStringParam("work_phone",memberDetails.getWorkPhone())
                .addStringParam("email",memberDetails.getEmail())
                .addStringParam("notes",memberDetails.getNotes())
                .addStringParam("fingerprint_1","");

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(smr);

    }



    public class MemberRegisterTask extends AsyncTask<String,String,String>{

        private Context context;
        MemberPOJO member;
        String token;
        MemberRegisterTask(Context context,MemberPOJO member,String token){
            this.context=context;
            this.member=member;
            this.token=token;
        }
        @Override
        protected String doInBackground(String... strings) {

            HashMap<String,String> postData = new HashMap<String, String>();
            postData.put("token", token);
            postData.put("first_name",member.getFirstName());
            postData.put("middle_name","");
            postData.put("last_name",member.getLastName());
            postData.put("gender",member.getGender());
            postData.put("marital_status",member.getMaritalStatus());
            postData.put("status",member.getStatus());
            postData.put("mobile_phone",member.getMobilePhone());
            postData.put("dob",member.getDob());
            postData.put("address",member.getAddress());
            postData.put("fingerprint",member.getFingerPrint());
            postData.put("home_phone",member.getHomePhone());
            postData.put("work_phone",member.getWorkPhone());
            postData.put("email",member.getEmail());
            postData.put("notes",member.getNotes());
            postData.put("fingerprint_1",member.getFingerPrint1());
            String url = "http://52.172.221.235:8983/api/create_member";//http://52.172.221.235:8983/api/create_member
            String json_output = WebServiceCall.performPostCall(url, postData);
            return json_output;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);


            Toast.makeText(MemberRegisterActivity.this,s,Toast.LENGTH_LONG).show();

            Toast.makeText(MemberRegisterActivity.this, "Saved successfully", Toast.LENGTH_SHORT).show();
            if (isPhone){
                SerialPortManagerA5.getInstance().closeSerialPort();
                finish();
                progressBar.setVisibility(View.INVISIBLE);
            }
            if (isTablet) {
                SerialPortManager.getInstance().closeSerialPort();
                finish();
                progressBar.setVisibility(View.INVISIBLE);
            }
        }
    }


    //----------------------------------------------
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case Utility.MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if(userChoosenTask.equals("Take Photo"))
                        cameraIntent();
                    else if(userChoosenTask.equals("Choose from Library"))
                        galleryIntent();
                } else {
                    //code for deny
                }
                break;
        }
    }

    private void selectImage() {
        final CharSequence[] items = { "Take Photo", "Choose from Library",
                "Cancel" };

        AlertDialog.Builder builder = new AlertDialog.Builder(MemberRegisterActivity.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                boolean result=Utility.checkPermission(MemberRegisterActivity.this);

                if (items[item].equals("Take Photo")) {
                    userChoosenTask ="Take Photo";
                    if(result)
                        cameraIntent();

                } else if (items[item].equals("Choose from Library")) {
                    userChoosenTask ="Choose from Library";
                    if(result)
                        galleryIntent();

                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void galleryIntent() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_FILE);
    }

    private void cameraIntent() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_CAMERA)
                onCaptureImageResult(data);
        }
    }

    private void onCaptureImageResult(Intent data) {
        bitmapImage = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmapImage.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        String fileName=System.currentTimeMillis() + ".jpg";
        destination = new File(Environment.getExternalStorageDirectory(),
                fileName);
    //    setImagePath(fileName);
        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Toast.makeText(MemberRegisterActivity.this,destination.getAbsolutePath(),Toast.LENGTH_LONG).show();
        imageViewFingerPrint2.setImageBitmap(bitmapImage);
        setImagePath(destination.getAbsolutePath());
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {

        bitmapImage=null;
        String path ="";
        if (data != null) {
            try {
                bitmapImage = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());

                Cursor cursor = getContentResolver().query(data.getData(), null, null, null, null);
                cursor.moveToFirst();
                String document_id = cursor.getString(0);
                document_id = document_id.substring(document_id.lastIndexOf(":") + 1);
                cursor.close();

                cursor = getContentResolver().query(
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        null, MediaStore.Images.Media._ID + " = ? ", new String[]{document_id}, null);


                cursor.moveToFirst();
                path = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));

                cursor.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Toast.makeText(MemberRegisterActivity.this,path,Toast.LENGTH_LONG).show();
        imageViewFingerPrint2.setImageBitmap(bitmapImage);
        setImagePath(path);
    }

    public void setImagePath(String path){
        imagePath=path;
    }

    public String getImagePath(){
        return imagePath;
    }

//*******************************************************
}