package in.co.ashclan.fingerprint;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

import in.co.ashclan.adpater.MemberAdapter;
import in.co.ashclan.model.MemberPOJO;


public class MemberFragment extends Fragment{
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String LIST = "list";
    private String mParam1;
    private String mParam2;
    ListView listView;
    //private OnFragmentInteractionListener mListener;

    ArrayList<MemberPOJO> list = new ArrayList<MemberPOJO>();

    public MemberFragment() {
    }

    public static MemberFragment newInstance(ArrayList<MemberPOJO> list) {
        MemberFragment fragment = new MemberFragment();
        Bundle args = new Bundle();
        args.putSerializable(LIST,list);
        fragment.setArguments(args);
        return fragment;
    }


    public static MemberFragment newInstance(String param1, String param2) {
        MemberFragment fragment = new MemberFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            list = (ArrayList<MemberPOJO>)getArguments().getSerializable(LIST);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_member,
                container, false);
        MemberAdapter memberAdapter = new MemberAdapter(MemberFragment.this.getActivity(),list,"ic_person.png");
        listView = (ListView)view.findViewById(R.id.list);
        listView.setAdapter(memberAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                MemberPOJO memberDetails = list.get(i);
                Intent intent = new Intent(getActivity().getApplication(),MemberDetailsActivity.class);
                intent.putExtra("member_details",memberDetails);
                startActivity(intent);
                getActivity().finish();
            }
        });

    return view;
    }
}
